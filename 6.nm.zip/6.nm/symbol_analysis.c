#include <stdio.h>

void function1() {
    printf("Function 1\n");
}

void function2() {
    printf("Function 2\n");
}

int main() {
    function1();
    function2();
    return 0;
}
