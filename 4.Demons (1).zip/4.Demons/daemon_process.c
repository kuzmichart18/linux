// Разработчик - Лазарева Виктория, 35ИС-21 КМПО РАНХиГС
// Процессы-демоны
// Задача: Создать демон-процесс в Linux.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

int main() {
    pid_t pid;

    pid = fork();
    if (pid < 0) {
        exit(EXIT_FAILURE);
    }
    if (pid > 0) {
        exit(EXIT_SUCCESS); 
    }

    umask(0);
    if (setsid() < 0) {
        exit(EXIT_FAILURE);
    }

    printf("Демон запущен.\n");
    while (1) {
        sleep(60); 
    }

    return 0; 
}
