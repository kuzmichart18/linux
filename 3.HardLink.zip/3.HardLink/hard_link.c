#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    if (link("source.txt", "new_link.txt") == -1) {
        perror("link");
        exit(EXIT_FAILURE);
    }
    printf("Жесткая ссылка успешно создана.\n");
    return 0;
}
