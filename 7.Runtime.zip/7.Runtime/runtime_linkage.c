#include <stdio.h>
#include <dlfcn.h>

int main() {
    void *handle;
    int (*add)(int, int);

    handle = dlopen("./library.so", RTLD_LAZY);
    if (!handle) {
        fprintf(stderr, "%s\n", dlerror());
        return 1;
    }


    add = dlsym(handle, "add");
    if (!add) {
        fprintf(stderr, "%s\n", dlerror());
        dlclose(handle);
        return 1;
    }


    printf("Результат сложения: %d\n", add(5, 3));

    
    dlclose(handle);

    return 0;
}
