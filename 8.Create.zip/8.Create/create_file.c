#include <stdio.h>

int main() {
    FILE *fp;

    fp = fopen("output.txt", "w");

    if (fp == NULL) {
        printf("Ошибка при открытии файла.\n");
        return 1;
    }

    fprintf(fp, "Привет, мир!");

    fclose(fp);

    printf("Файл успешно создан и текст успешно записан.\n");

    return 0;
}
