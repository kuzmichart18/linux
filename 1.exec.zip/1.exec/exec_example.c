// Разработчик - Лазарева Виктория, 35ИС-21 КМПО РАНХиГС
// exec


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    char *args[] = {"echo", "Hello, world!", NULL};
    execvp("echo", args);
    perror("execvp");  // Сюда программа вернется только в случае ошибки
    exit(EXIT_FAILURE);
}
