#!/bin/bash
./exec_example > output.txt
if grep -q "Hello, world!" output.txt; then
    echo "Тест пройден: вывод корректен."
else
    echo "Тест не пройден: вывод некорректен."
fi
