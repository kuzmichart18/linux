#include <stdio.h>

int main() {
    setbuf(stdout, NULL); 

    printf("Hello, world!\n");

    return 0;
}
