#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s process_name\n", argv[0]);
        return EXIT_FAILURE;
    }

    char command[256];
    sprintf(command, "pgrep -c %s", argv[1]);

    FILE *fp = popen(command, "r");
    if (fp == NULL) {
        perror("Failed to run command");
        exit(EXIT_FAILURE);
    }

    char num_procs[10];
    if (fgets(num_procs, sizeof(num_procs), fp) != NULL) {
        printf("Number of processes named '%s': %s", argv[1], num_procs);
    }

    pclose(fp);
    return 0;
}
